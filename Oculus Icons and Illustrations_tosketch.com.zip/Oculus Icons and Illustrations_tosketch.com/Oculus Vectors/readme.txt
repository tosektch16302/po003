
Oculus technical illustrations and icons by Tanner Christensen. Learn more about Tanner’s work at http://tannerc.com.

Terms of Use:

Oculus illustrations and icons are available for free for use in both personal and commercial projects. The works presented are licensed under Creative Commons Attribution-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nd/4.0/).

You may freely use the works presented without restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or links are required, but any form of spreading the word is always appreciated.

This work is in no way affiliated with the official company or Oculus brand, nor any Oculus partners or clients.